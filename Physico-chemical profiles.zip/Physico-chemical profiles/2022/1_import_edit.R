#source(path to install and load packages)

#m1
ctd.m1_b <- readxl::read_xlsx("#path to CTD data") #cast at m1 in the morning (before incubation)
ctd.m1_a <- readxl::read_xlsx("#path to CTD data") #cast at m1 in the afternoon (after incubation)
#s0a
ctd.s0_b <- readxl::read_xlsx("#path to CTD data") #cast at s0 in the morning (before incubation)
ctd.s0_a <- readxl::read_xlsx("#path to CTD data") #cast at s0 in the afternoon (after incubation)
#p4
ctd.p4_b <- readxl::read_xlsx("#path to CTD data")#cast at p4 in the morning (before incubation)
ctd.p4_a <-readxl::read_xlsx("#path to CTD data") #cast at p4 in the afternoon (after incubation)


# Edit and merge CTD data (for a single data frame)
process_ctd_data <- function(df) {
  
  df %>%
    # Remove unwanted columns by column index
    select(-c(4, 8, 9)) %>%
    # Rename columns
    rename(
      Depth = DepSM, 
      Temp = Tv290C, 
      `Chl F` = `FlECO.AFL`, 
      Salinity = Sal00, 
      `Sigma-t` = `Sigma.t00`, 
      `Oxygen_mgL-1` = `Sbeox0Mg.L`
    ) %>%
    # Convert character columns to numeric (if needed)
    mutate(across(where(is.character), as.numeric)) %>%
    # Filter to keep only depths less than or equal to 65 m
    filter(Depth >= 2 & Depth <= 65)
}

# Apply the function to your CTD dataframe
CTDm1_a <- process_ctd_data(ctd.m1_a)
CTDm1_b <- process_ctd_data(ctd.m1_b)
CTDp4_a <- process_ctd_data(ctd.p4_a)
CTDp4_b <- process_ctd_data(ctd.p4_b)
CTDs0_a <- process_ctd_data(ctd.s0_a)
CTDs0_b <- process_ctd_data(ctd.s0_b)
