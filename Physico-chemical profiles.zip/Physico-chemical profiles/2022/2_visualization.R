#source(path to install and load packages)

##############################M1 STATION#########################################
p1 <- plot_ly(data = CTDm1_b, x = ~Temp, y = ~Depth,
            type = 'scatter', mode = 'lines',
            line = list(color = 'red', dash = 'dash'), showlegend = FALSE) %>%
    add_trace(data = CTDm1_a, x = ~Temp, y = ~Depth, 
            type = 'scatter', mode = 'lines', 
            line = list(color = 'red', dash = 'solid'), showlegend = FALSE) %>%
    layout(xaxis = list(title = "Temperature [°C]", 
                      autorange = FALSE,
                      fixedrange = TRUE,  # Fix the range to enforce limits
                      range = c(15,24),
                      side = "top",          
                      titlefont = list(size = 30, family = "Calibri"),  
                      tickfont = list(size = 25),
                      showgrid = FALSE),  
         yaxis = list(title = "- z [m]", 
                      range = c(70,0),  
                      side = "left",          
                      titlefont = list(size = 30, family = "Calibri"),  
                      tickfont = list(size = 25),
                      linewidth = 1,
                      showgrid = FALSE))

p2 <- plot_ly(data = CTDm1_b, x = ~ `Oxygen_mgL-1`, y = ~Depth,
        type = 'scatter', mode = 'lines',
        line = list(color = 'grey', dash = 'dash'), showlegend = FALSE) %>%
  add_trace(data = CTDm1_a, x = ~ `Oxygen_mgL-1`, y = ~Depth, 
            type = 'scatter', mode = 'lines', 
            line = list(color = 'grey', dash = 'solid'), showlegend = FALSE) %>%
  layout(xaxis = list(title = "Oxygen [mg L<sup>-1</sup>]", 
                      side = "top",
                      autorange = FALSE,
                      fixedrange = TRUE,  # Fix the range to enforce limits
                      range = c(6.5,8.5),
                      titlefont = list(size = 30, family = "Calibri"),  
                      tickfont = list(size = 25),
                      showgrid = FALSE),  
         yaxis = list(#title = "- z [m]", 
                      range = c(70,0),  
                      side = "left",          
                      titlefont = list(size = 30, family = "Calibri"),  
                      tickfont = list(size = 25),
                      linewidth = 1,
                      showgrid = FALSE))

p3 <- plot_ly(data = CTDm1_b, x = ~ `Chl F`, y = ~Depth,
              type = 'scatter', mode = 'lines',
              line = list(color = 'darkgreen', dash = 'dash'), showlegend = FALSE) %>%
  add_trace(data = CTDm1_a, x = ~ `Chl F`, y = ~Depth, 
            type = 'scatter', mode = 'lines', 
            line = list(color = 'darkgreen', dash = 'solid'), showlegend = FALSE) %>%
  layout(xaxis = list(title = "Chl fluorescence [mg m<sup>-3</sup>]", 
                      side = "top",  
                      autorange = FALSE,
                      fixedrange = TRUE,  # Fix the range to enforce limits
                      range = c(-0.2,0.8),         
                      titlefont = list(size = 30, family = "Calibri"),  
                      tickfont = list(size = 25),
                      zeroline = FALSE,
                      showgrid = FALSE),  
         yaxis = list(#title = "- z [m]", 
                      range = c(70,0),  
                      side = "left",          
                      titlefont = list(size = 30, family = "Calibri"),  
                      tickfont = list(size = 25),
                      linewidth = 1,
                      showgrid = FALSE))

# Combine the plots into a subplot
plot <-  subplot(p1, p2, p3, nrows = 1, titleX = TRUE, titleY = TRUE) %>%
  layout(showlegend = TRUE)

# Display the final plot
plot


##############################S0 STATION#########################################

p4 <- plot_ly(data = CTDs0_b, x = ~Temp, y = ~Depth,
              type = 'scatter', mode = 'lines',
              line = list(color = 'red', dash = 'dash'), showlegend = FALSE) %>%
  add_trace(data = CTDs0_a, x = ~Temp, y = ~Depth, 
            type = 'scatter', mode = 'lines', 
            line = list(color = 'red', dash = 'solid'), showlegend = FALSE) %>%
  layout(xaxis = list(#title = "Temperature [°C]", 
                      side = "top",
                      autorange = FALSE,
                      fixedrange = TRUE,  # Fix the range to enforce limits
                      range = c(15,24),
                      titlefont = list(size = 30, family = "Calibri"),  
                      tickfont = list(size = 25),
                      showgrid = FALSE),  
         yaxis = list(title = "- z [m]", 
                      range = c(70,0),  
                      side = "left",          
                      titlefont = list(size = 30, family = "Calibri"),  
                      tickfont = list(size = 25),
                      linewidth = 1,
                      showgrid = FALSE))

p5 <- plot_ly(data = CTDs0_b, x = ~ `Oxygen_mgL-1`, y = ~Depth,
              type = 'scatter', mode = 'lines',
              line = list(color = 'grey', dash = 'dash'), showlegend = FALSE) %>%
  add_trace(data = CTDs0_a, x = ~ `Oxygen_mgL-1`, y = ~Depth, 
            type = 'scatter', mode = 'lines', 
            line = list(color = 'grey', dash = 'solid'), showlegend = FALSE) %>%
  layout(xaxis = list(#title = "Oxygen [mg L<sup>-1</sup>]", 
                      side = "top",  
                      autorange = FALSE,
                      fixedrange = TRUE,  # Fix the range to enforce limits
                      range = c(6.5,8.5),
                      titlefont = list(size = 30, family = "Calibri"),  
                      tickfont = list(size = 25),
                      showgrid = FALSE),  
         yaxis = list(#title = "- z [m]", 
                      range = c(70,0),  
                      side = "left",          
                      titlefont = list(size = 30, family = "Calibri"),  
                      tickfont = list(size = 25),
                      linewidth = 1,
                      showgrid = FALSE))

p6 <- plot_ly(data = CTDs0_b, x = ~ `Chl F`, y = ~Depth,
              type = 'scatter', mode = 'lines',
              line = list(color = 'darkgreen', dash = 'dash'), showlegend = FALSE) %>%
  add_trace(data = CTDs0_a, x = ~ `Chl F`, y = ~Depth, 
            type = 'scatter', mode = 'lines', 
            line = list(color = 'darkgreen', dash = 'solid'), showlegend = FALSE) %>%
  layout(xaxis = list(#title = "Chlorophyll fluorescence [mg m<sup>-3</sup>]", 
                      side = "top",  
                      autorange = FALSE,
                      fixedrange = TRUE,  # Fix the range to enforce limits
                      range = c(-0.2,0.9), 
                      titlefont = list(size = 30, family = "Calibri"),  
                      tickfont = list(size = 25),
                      zeroline = FALSE,
                      showgrid = FALSE),  
         yaxis = list(#title = "- z [m]", 
                      range = c(70,0),  
                      side = "left",          
                      titlefont = list(size = 30, family = "Calibri"),  
                      tickfont = list(size = 25),
                      linewidth = 1,
                      showgrid = FALSE))

# Combine the plots into a subplot
plot2 <-  subplot(p4, p5, p6, nrows = 1, titleX = TRUE, titleY = TRUE) %>%
  layout(showlegend = TRUE)

# Display the final plot
plot2


##############################P4 STATION#########################################
p7 <- plot_ly(data = CTDp4_b, x = ~Temp, y = ~Depth,
              type = 'scatter', mode = 'lines',
              line = list(color = 'red', dash = 'dash'), showlegend = FALSE) %>%
  add_trace(data = CTDp4_a, x = ~Temp, y = ~Depth, 
            type = 'scatter', mode = 'lines', 
            line = list(color = 'red', dash = 'solid'), showlegend = FALSE) %>%
  layout(xaxis = list(#title = "Temperature [°C]", 
                      side = "top", 
                      autorange = FALSE,
                      fixedrange = TRUE,  # Fix the range to enforce limits
                      range = c(15,24),        
                      titlefont = list(size = 30, family = "Calibri"),  
                      tickfont = list(size = 25),
                      showgrid = FALSE),  
         yaxis = list(title = "- z [m]", 
                      range = c(70,0),  
                      side = "left",          
                      titlefont = list(size = 30, family = "Calibri"),  
                      tickfont = list(size = 25),
                      linewidth = 1,
                      showgrid = FALSE))

p8 <- plot_ly(data = CTDp4_b, x = ~ `Oxygen_mgL-1`, y = ~Depth,
              type = 'scatter', mode = 'lines',
              line = list(color = 'grey', dash = 'dash'), showlegend = FALSE) %>%
  add_trace(data = CTDp4_a, x = ~ `Oxygen_mgL-1`, y = ~Depth, 
            type = 'scatter', mode = 'lines', 
            line = list(color = 'grey', dash = 'solid'), showlegend = FALSE) %>%
  layout(xaxis = list(#title = "Oxygen [mg L<sup>-1</sup>]", 
                      side = "top", 
                      autorange = FALSE,
                      fixedrange = TRUE,  # Fix the range to enforce limits
                      range = c(6.5,8.5),
                      titlefont = list(size = 30, family = "Calibri"),  
                      tickfont = list(size = 25),
                      showgrid = FALSE),  
         yaxis = list(#title = "- z [m]", 
                      range = c(70,0),  
                      side = "left",          
                      titlefont = list(size = 30, family = "Calibri"),  
                      tickfont = list(size = 25),
                      linewidth = 1,
                      showgrid = FALSE))

p9 <- plot_ly(data = CTDp4_b, x = ~ `Chl F`, y = ~Depth,
              type = 'scatter', mode = 'lines',
              line = list(color = 'darkgreen', dash = 'dash'), showlegend = FALSE) %>%
  add_trace(data = CTDp4_a, x = ~ `Chl F`, y = ~Depth, 
            type = 'scatter', mode = 'lines', 
            line = list(color = 'darkgreen', dash = 'solid'), showlegend = FALSE) %>%
  layout(xaxis = list(#title = "Chlorophyll fluorescence [mg m<sup>-3</sup>]", 
                      side = "top",      
                      autorange = FALSE,
                      fixedrange = TRUE,  # Fix the range to enforce limits
                      range = c(-0.2,0.9), 
                      titlefont = list(size = 30, family = "Calibri"),  
                      tickfont = list(size = 25),
                      zeroline = FALSE,
                      showgrid = FALSE),  
         yaxis = list(#title = "- z [m]", 
                      range = c(70,0),  
                      side = "left",          
                      titlefont = list(size = 30, family = "Calibri"),  
                      tickfont = list(size = 25),
                      linewidth = 1,
                      showgrid = FALSE))

# Combine the plots into a subplot
plot3 <-  subplot(p7, p8, p9, nrows = 1, titleX = TRUE, titleY = TRUE) %>%
  layout(showlegend = TRUE)

# Display the final plot
plot3


final_plot <-  subplot(plot, plot2, plot3, nrows = 3, titleX = TRUE, titleY = TRUE) %>%
  layout(showlegend = TRUE)

final_plot

#save image
htmlwidgets::saveWidget(as_widget(final_plot), "plot.html")
webshot::webshot("plot.html", file = "vertical_profiles_22.jpg", vwidth = 1500, vheight = 1500)
