#source(path to install and load packages)

#################################NUTRIENTS#########################################################
#insert path to nutrient concentrations in 2023
nut04 <- readxl::read_xlsx("path")
nut08 <- readxl::read_xlsx("path")
nut16 <- readxl::read_xlsx("path")

#function to process the nutrient data
process_nutrient_data <- function(df) {
  df %>%
    # Remove Nitrite column
    select(-`Nitrite [µmol/L]`) %>%
    # Remove TON column
    select(-`TON [µmol/L]`) %>%
    # Replace <LOD with NA in all character columns
    mutate(across(where(is.character), ~na_if(., "<LOD"))) %>%
    # Convert character columns back to numeric
    mutate(across(where(is.character), as.numeric)) %>%
    # Group by depth (z [m]) and compute the mean for each group
    group_by(`z [m]`) %>%
    summarise(across(everything(), mean, na.rm = TRUE)) %>%
    ungroup()
}

# apply the function
nut04_avg <- process_nutrient_data(nut04)
nut08_avg <- process_nutrient_data(nut08)
nut16_avg <- process_nutrient_data(nut16)


##############################CTD DATA#######################################

#4th July
ctd04_b <- readxl::read_xlsx("#path to CTD data") #before incubation
ctd04_a <- readxl::read_xlsx("#path to CTD data") #after incubation
#8th July
ctd08_b <- readxl::read_xlsx("#path to CTD data") #before incubation
ctd08_a <- readxl::read_xlsx("#path to CTD data") #after incubation
#16th July
ctd16_b <- readxl::read_xlsx("#path to CTD data") #before incubation
ctd16_a <- readxl::read_xlsx("#path to CTD data") #after incubation



# Edit and merge CTD data (for a single data frame)
process_ctd_data <- function(df) {
  
  df %>%
    # Remove unwanted columns by column index
    select(-c(4, 8, 9)) %>%
    # Rename columns
    rename(
      Depth = DepSM, 
      Temp = Tv290C, 
      `Chl F` = `FlECO-AFL`, 
      Salinity = Sal00, 
      `Sigma-t` = `Sigma-t00`, 
      `Oxygen_mgL-1` = `Sbeox0Mg/L`
    ) %>%
    # Convert character columns to numeric (if needed)
    mutate(across(where(is.character), as.numeric)) %>%
    # Filter to keep only depths less than or equal to 65 m
    filter(Depth >= 2 & Depth <= 65)
}

# Apply the function to your CTD dataframe
CTD04_a <- process_ctd_data(ctd04_a)
CTD04_b <- process_ctd_data(ctd04_b)
CTD08_a <- process_ctd_data(ctd08_a)
CTD08_b <- process_ctd_data(ctd08_b)
CTD16_a <- process_ctd_data(ctd16_a)
CTD16_b <- process_ctd_data(ctd16_b)

