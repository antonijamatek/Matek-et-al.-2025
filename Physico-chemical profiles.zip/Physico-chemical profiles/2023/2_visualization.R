#source(path to install and load packages)

##############################4TH JULY#########################################

p1 <- plot_ly(nut04_avg, 
              x = ~`Phosphate [µmol/L]`, y = ~`z [m]`, 
              type = 'scatter', mode = 'lines+markers', 
              name = 'Phosphate', 
              line = list(color = "black", dash = 'dash'), 
              marker = list(color = 'red', symbol = 'circle', size = 15), # Circle for phosphate
              showlegend = TRUE) %>%
  add_trace(x = ~`Silicate [µmol/L]`, y = ~`z [m]`, 
            name = 'Silicate', 
            line = list(color = "black", dash = 'dash'), 
            marker = list(color = 'blue', symbol = 'circle', size = 15), # Square for silicate
            showlegend = TRUE) %>%
  add_trace(x = ~`Nitrate [µmol/L]`, y = ~`z [m]`, 
            name = 'Nitrate', 
            line = list(color = "black", dash = 'dash'), 
            marker = list(color = 'green', symbol = 'circle', size = 15), # Star for nitrate
            showlegend = TRUE) %>%
  layout(
    xaxis = list(
      title = "Nutrients [µmol L<sup>-1</sup>]", 
      side = "top",
      autorange = FALSE,
      fixedrange = TRUE,  # Fix the range to enforce limits
      range = c(0, 4),
      titlefont = list(size = 30, family = "Calibri"),  
      tickfont = list(size = 25),
      showgrid = FALSE
    ),  
    yaxis = list(
      #title = "- z [m]", 
      range = c(70, 0),
      side = "left",          
      titlefont = list(size = 30, family = "Calibri"),  
      tickfont = list(size = 25),
      showgrid = FALSE
    ),
    legend = list(font = list(size = 30))
  )


p2 <- plot_ly(data = CTD04_b, x = ~Temp, y = ~Depth,
            type = 'scatter', mode = 'lines',
            line = list(color = 'red', dash = 'dash'), showlegend = FALSE) %>%
    add_trace(data = CTD04_a, x = ~Temp, y = ~Depth, 
            type = 'scatter', mode = 'lines', 
            line = list(color = 'red', dash = 'solid'), showlegend = FALSE) %>%
    layout(xaxis = list(title = "Temperature [°C]", 
                      autorange = FALSE,
                      fixedrange = TRUE,  # Fix the range to enforce limits
                      range = c(15,26),
                      side = "top",          
                      titlefont = list(size = 30, family = "Calibri"),  
                      tickfont = list(size = 25),
                      showgrid = FALSE),  
         yaxis = list(title = "- z [m]", 
                      range = c(70,0),  
                      side = "left",          
                      titlefont = list(size = 30, family = "Calibri"),  
                      tickfont = list(size = 25),
                      linewidth = 1,
                      showgrid = FALSE))

p3 <- plot_ly(data = CTD04_b, x = ~ `Oxygen_mgL-1`, y = ~Depth,
        type = 'scatter', mode = 'lines',
        line = list(color = 'grey', dash = 'dash'), showlegend = FALSE) %>%
  add_trace(data = CTD04_a, x = ~ `Oxygen_mgL-1`, y = ~Depth, 
            type = 'scatter', mode = 'lines', 
            line = list(color = 'grey', dash = 'solid'), showlegend = FALSE) %>%
  layout(xaxis = list(title = "Oxygen [mg L<sup>-1</sup>]", 
                      side = "top",
                      autorange = FALSE,
                      fixedrange = TRUE,  # Fix the range to enforce limits
                      range = c(5,10),
                      titlefont = list(size = 30, family = "Calibri"),  
                      tickfont = list(size = 25),
                      showgrid = FALSE),  
         yaxis = list(#title = "- z [m]", 
                      range = c(70,0),  
                      side = "left",          
                      titlefont = list(size = 30, family = "Calibri"),  
                      tickfont = list(size = 25),
                      linewidth = 1,
                      showgrid = FALSE))

p4 <- plot_ly(data = CTD04_b, x = ~ `Chl F`, y = ~Depth,
              type = 'scatter', mode = 'lines',
              line = list(color = 'darkgreen', dash = 'dash'), showlegend = FALSE) %>%
  add_trace(data = CTD04_a, x = ~ `Chl F`, y = ~Depth, 
            type = 'scatter', mode = 'lines', 
            line = list(color = 'darkgreen', dash = 'solid'), showlegend = FALSE) %>%
  layout(xaxis = list(title = "Chl fluorescence [mg m<sup>-3</sup>]", 
                      side = "top",  
                      autorange = FALSE,
                      fixedrange = TRUE,  # Fix the range to enforce limits
                      range = c(-0.2,0.7),         
                      titlefont = list(size = 30, family = "Calibri"),  
                      tickfont = list(size = 25),
                      zeroline = FALSE,
                      showgrid = FALSE),  
         yaxis = list(#title = "- z [m]", 
                      range = c(70,0),  
                      side = "left",          
                      titlefont = list(size = 30, family = "Calibri"),  
                      tickfont = list(size = 25),
                      linewidth = 1,
                      showgrid = FALSE))

# Combine the plots into a subplot
plot <-  subplot(p2, p3, p4, p1, nrows = 1, titleX = TRUE, titleY = TRUE) %>%
  layout(showlegend = TRUE)

# Display the final plot
plot


##############################8TH JULY#########################################
p5 <- plot_ly(nut08_avg, x = ~`Phosphate [µmol/L]`, y = ~`z [m]`, 
              type = 'scatter', mode = 'lines+markers', 
              name = 'Phosphate', 
              line = list(color = "black", dash = 'dash'), 
              marker = list(color = 'red', symbol = 'circle', size = 15),  showlegend = FALSE) %>%
  add_trace(x = ~`Silicate [µmol/L]`, y = ~`z [m]`, 
            name = 'Silicate', 
            line = list(color = "black", dash = 'dash'), 
            marker = list(color = 'blue', symbol = 'circle', size = 15),  showlegend = FALSE) %>%
  add_trace(x = ~`Nitrate [µmol/L]`, y = ~`z [m]`, 
            name = 'Nitrate', 
            line = list(color = "black", dash = 'dash'), 
            marker = list(color = 'green', symbol = 'circle', size = 15),  showlegend = FALSE) %>%
  layout(xaxis = list(#title = "Nutrient Concentration [µmol L<sup>-1</sup>]", 
                      side = "top",
                      autorange = FALSE,
                      fixedrange = TRUE,  # Fix the range to enforce limits
                      range = c(0,4),
                      titlefont = list(size = 30, family = "Calibri"),  
                      tickfont = list(size = 25),
                      showgrid = FALSE),  
         yaxis = list(#title = "- z [m]", 
                      range = c(70,0),  
                      side = "left",          
                      titlefont = list(size = 30, family = "Calibri"),  
                      tickfont = list(size = 25),
                      showgrid = FALSE))

p6 <- plot_ly(data = CTD08_b, x = ~Temp, y = ~Depth,
              type = 'scatter', mode = 'lines',
              line = list(color = 'red', dash = 'dash'), showlegend = FALSE) %>%
  add_trace(data = CTD08_a, x = ~Temp, y = ~Depth, 
            type = 'scatter', mode = 'lines', 
            line = list(color = 'red', dash = 'solid'), showlegend = FALSE) %>%
  layout(xaxis = list(#title = "Temperature [°C]", 
                      side = "top",
                      autorange = FALSE,
                      fixedrange = TRUE,  # Fix the range to enforce limits
                      range = c(15,26),
                      titlefont = list(size = 30, family = "Calibri"),  
                      tickfont = list(size = 25),
                      showgrid = FALSE),  
         yaxis = list(title = "- z [m]", 
                      range = c(70,0),  
                      side = "left",          
                      titlefont = list(size = 30, family = "Calibri"),  
                      tickfont = list(size = 25),
                      linewidth = 1,
                      showgrid = FALSE))

p7 <- plot_ly(data = CTD08_b, x = ~ `Oxygen_mgL-1`, y = ~Depth,
              type = 'scatter', mode = 'lines',
              line = list(color = 'grey', dash = 'dash'), showlegend = FALSE) %>%
  add_trace(data = CTD08_a, x = ~ `Oxygen_mgL-1`, y = ~Depth, 
            type = 'scatter', mode = 'lines', 
            line = list(color = 'grey', dash = 'solid'), showlegend = FALSE) %>%
  layout(xaxis = list(#title = "Oxygen [mg L<sup>-1</sup>]", 
                      side = "top",  
                      autorange = FALSE,
                      fixedrange = TRUE,  # Fix the range to enforce limits
                      range = c(5,10),
                      titlefont = list(size = 30, family = "Calibri"),  
                      tickfont = list(size = 25),
                      showgrid = FALSE),  
         yaxis = list(#title = "- z [m]", 
                      range = c(70,0),  
                      side = "left",          
                      titlefont = list(size = 30, family = "Calibri"),  
                      tickfont = list(size = 25),
                      linewidth = 1,
                      showgrid = FALSE))

p8 <- plot_ly(data = CTD08_b, x = ~ `Chl F`, y = ~Depth,
              type = 'scatter', mode = 'lines',
              line = list(color = 'darkgreen', dash = 'dash'), showlegend = FALSE) %>%
  add_trace(data = CTD08_a, x = ~ `Chl F`, y = ~Depth, 
            type = 'scatter', mode = 'lines', 
            line = list(color = 'darkgreen', dash = 'solid'), showlegend = FALSE) %>%
  layout(xaxis = list(#title = "Chlorophyll fluorescence [mg m<sup>-3</sup>]", 
                      side = "top",  
                      autorange = FALSE,
                      fixedrange = TRUE,  # Fix the range to enforce limits
                      range = c(-0.2,0.7),
                      titlefont = list(size = 30, family = "Calibri"),  
                      tickfont = list(size = 25),
                      zeroline = FALSE,
                      showgrid = FALSE),  
         yaxis = list(#title = "- z [m]", 
                      range = c(70,0),  
                      side = "left",          
                      titlefont = list(size = 30, family = "Calibri"),  
                      tickfont = list(size = 25),
                      linewidth = 1,
                      showgrid = FALSE))

# Combine the plots into a subplot
plot2 <-  subplot(p6, p7, p8, p5, nrows = 1, titleX = TRUE, titleY = TRUE) %>%
  layout(showlegend = TRUE)

# Display the final plot
plot2


##############################16TH JULY#########################################
p9 <- plot_ly(nut16_avg, x = ~`Phosphate [µmol/L]`, y = ~`z [m]`, 
              type = 'scatter', mode = 'lines+markers', 
              name = 'Phosphate', 
              line = list(color = "black", dash = 'dash'), 
              marker = list(color = 'red', symbol = 'circle', size = 15),  showlegend = FALSE) %>%
  add_trace(x = ~`Silicate [µmol/L]`, y = ~`z [m]`, 
            name = 'Silicate', 
            line = list(color = "black", dash = 'dash'), 
            marker = list(color = 'blue', symbol = 'circle', size = 15),  showlegend = FALSE) %>%
  add_trace(x = ~`Nitrate [µmol/L]`, y = ~`z [m]`, 
            name = 'Nitrate', 
            line = list(color = "black", dash = 'dash'), 
            marker = list(color = 'green', symbol = 'circle', size = 15),  showlegend = FALSE) %>%
  layout(xaxis = list(#title = "Nutrient Concentration [µmol L<sup>-1</sup>]", 
                      side = "top",
                      autorange = FALSE,
                      fixedrange = TRUE,  # Fix the range to enforce limits
                      range = c(0,4),
                      titlefont = list(size = 30, family = "Calibri"),  
                      tickfont = list(size = 25),
                      showgrid = FALSE),  
         yaxis = list(#title = "- z [m]", 
                      range = c(70,0),  
                      side = "left",          
                      titlefont = list(size = 30, family = "Calibri"),  
                      tickfont = list(size = 25),
                      showgrid = FALSE))

p10 <- plot_ly(data = CTD16_b, x = ~Temp, y = ~Depth,
              type = 'scatter', mode = 'lines',
              line = list(color = 'red', dash = 'dash'), showlegend = FALSE) %>%
  add_trace(data = CTD16_a, x = ~Temp, y = ~Depth, 
            type = 'scatter', mode = 'lines', 
            line = list(color = 'red', dash = 'solid'), showlegend = FALSE) %>%
  layout(xaxis = list(#title = "Temperature [°C]", 
                      side = "top", 
                      autorange = FALSE,
                      fixedrange = TRUE,  # Fix the range to enforce limits
                      range = c(15,26),        
                      titlefont = list(size = 30, family = "Calibri"),  
                      tickfont = list(size = 25),
                      showgrid = FALSE),  
         yaxis = list(title = "- z [m]", 
                      range = c(70,0),  
                      side = "left",          
                      titlefont = list(size = 30, family = "Calibri"),  
                      tickfont = list(size = 25),
                      linewidth = 1,
                      showgrid = FALSE))

p11 <- plot_ly(data = CTD16_b, x = ~ `Oxygen_mgL-1`, y = ~Depth,
              type = 'scatter', mode = 'lines',
              line = list(color = 'grey', dash = 'dash'), showlegend = FALSE) %>%
  add_trace(data = CTD16_a, x = ~ `Oxygen_mgL-1`, y = ~Depth, 
            type = 'scatter', mode = 'lines', 
            line = list(color = 'grey', dash = 'solid'), showlegend = FALSE) %>%
  layout(xaxis = list(#title = "Oxygen [mg L<sup>-1</sup>]", 
                      side = "top", 
                      autorange = FALSE,
                      fixedrange = TRUE,  # Fix the range to enforce limits
                      range = c(5,10),
                      titlefont = list(size = 30, family = "Calibri"),  
                      tickfont = list(size = 25),
                      showgrid = FALSE),  
         yaxis = list(#title = "- z [m]", 
                      range = c(70,0),  
                      side = "left",          
                      titlefont = list(size = 30, family = "Calibri"),  
                      tickfont = list(size = 25),
                      linewidth = 1,
                      showgrid = FALSE))

p12 <- plot_ly(data = CTD16_b, x = ~ `Chl F`, y = ~Depth,
              type = 'scatter', mode = 'lines',
              line = list(color = 'darkgreen', dash = 'dash'), showlegend = FALSE) %>%
  add_trace(data = CTD16_a, x = ~ `Chl F`, y = ~Depth, 
            type = 'scatter', mode = 'lines', 
            line = list(color = 'darkgreen', dash = 'solid'), showlegend = FALSE) %>%
  layout(xaxis = list(#title = "Chlorophyll fluorescence [mg m<sup>-3</sup>]", 
                      side = "top",      
                      autorange = FALSE,
                      fixedrange = TRUE,  # Fix the range to enforce limits
                      range = c(-0.2,0.7),
                      titlefont = list(size = 30, family = "Calibri"),  
                      tickfont = list(size = 25),
                      zeroline = FALSE,
                      showgrid = FALSE),  
         yaxis = list(#title = "- z [m]", 
                      range = c(70,0),  
                      side = "left",          
                      titlefont = list(size = 30, family = "Calibri"),  
                      tickfont = list(size = 25),
                      linewidth = 1,
                      showgrid = FALSE))

# Combine the plots into a subplot
plot3 <-  subplot(p10, p11, p12, p9, nrows = 1, titleX = TRUE, titleY = TRUE) %>%
  layout(showlegend = TRUE)

# Display the final plot
plot3



final_plot <-  subplot(plot, plot2, plot3, nrows = 3, titleX = TRUE, titleY = TRUE) %>%
  layout(showlegend = TRUE)

final_plot


#save image
htmlwidgets::saveWidget(as_widget(final_plot), "plot.html")
webshot::webshot("plot.html", file = "vertical_profiles_23.pdf", vwidth = 1700, vheight = 1300)
