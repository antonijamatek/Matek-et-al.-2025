#source(path to install and load packages)

#set the locale to English for time-related operations
Sys.setlocale("LC_TIME", "C")

load("par_for_K.Rdata") # generate in script "par22.time indexing and filtering.R"

time <- timestamp[timestamp >= as.POSIXct("2022-07-24") 
                         & timestamp < as.POSIXct("2022-08-07")
                         |
                           timestamp >= as.POSIXct("2022-08-22") 
                         & timestamp < as.POSIXct("2022-08-31")]

#filter out night
par10_aug <- dplyr::filter(par10_aug, !(as.POSIXlt(par10_aug$TimeStamp)$hour >= 20 
                                        | as.POSIXlt(par10_aug$TimeStamp)$hour < 6))
plot(par10_aug$TimeStamp, par10_aug$PAR_10)

par40_aug <- dplyr::filter(par40_aug, !(as.POSIXlt(par40_aug$TimeStamp)$hour >= 20
                                        | as.POSIXlt(par40_aug$TimeStamp)$hour < 6))
plot(par40_aug$TimeStamp, par40_aug$PAR_40)

#create df for estimate
par <- merge(par10_aug, par40_aug, by = "TimeStamp", suffixes = c("_10", "_40"))
