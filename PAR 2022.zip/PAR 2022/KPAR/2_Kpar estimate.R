#source(path to install and load packages)

#light function for Kpar estimate
#I <- I0 * e ^ (-Kpar * z)
#I/I0 <- e ^ (-Kpar * z) /ln
#ln(I/I0) <- - Kpar * z

e <- exp(1) #euler's number
deltaz <- 40 - 10 #difference between the depths

#input data frame for Kpar estimate
par

#input parameters
n <-unique(par$TimeStamp)
N <- as.numeric(length(n))
Kpar <- numeric(N)
I <- par$PAR_40
I0 <- par$PAR_10

#Kpar estimate
Kpar <- ln(I/I0) * -(1/deltaz)

#min and max Kpar depth
1/max(Kpar)
1/min(Kpar)
range(par$Kpar)

#edit data frame
par$Kpar <- Kpar

#plot
plot_ly(data = par[c(1:2352),], x = ~ TimeStamp, y = ~ Kpar, type = "scatter",
        mode = "markers")%>% layout(xaxis = list(title = "Dates"),
                                    yaxis = list(title = "Kpar(m-1) = ln(I/I0) * -(1/deltaz)"))

plot_ly(data = par[c(2353:3864),], x = ~ TimeStamp, y = ~ Kpar, type = "scatter",
        mode = "markers")%>% layout(xaxis = list(title = "Dates"),
                                    yaxis = list(title = "Kpar(m-1) = ln(I/I0) * -(1/deltaz)"))

par_corrected <- dplyr::filter(par, Kpar <= 0.12)

plot_ly(data = par_corrected[c(1:2075),], x = ~ TimeStamp, y = ~ Kpar, type = "scatter",
        mode = "markers")%>% layout(xaxis = list(title = "Dates"),
                                    yaxis = list(title = "Kpar(m-1) = ln(I/I0) * -(1/deltaz)"))

plot_ly(data = par_corrected[c(2076:3222),], x = ~ TimeStamp, y = ~ Kpar, type = "scatter",
        mode = "markers")%>% layout(xaxis = list(title = "Dates"),
                                    yaxis = list(title = "Kpar(m-1) = ln(I/I0) * -(1/deltaz)"))

#remove ''tails'' - leave data between 9:00 and 16:00
par_corrected <- dplyr::filter(par_corrected, !(as.POSIXlt(par_corrected$TimeStamp)$hour >= 16 | as.POSIXlt(par_corrected$TimeStamp)$hour < 9))
par_corrected <- dplyr::filter(par_corrected, Kpar <= 0.11)


plot_ly(data = par_corrected[c(1:855),], 
        x = ~TimeStamp, 
        y = ~Kpar, 
        type = "scatter", 
        mode = "markers") %>%
  layout(
    xaxis = list(title = "Dates"),
    yaxis = list(title = "Kpar(m-1) = ln(I/I0) * -(1/deltaz)")
  )


plot_ly(data = par_corrected[c(553:3864),], x = ~ TimeStamp, y = ~ Kpar, type = "scatter",
        mode = "markers")%>% layout(xaxis = list(title = "Dates"),
                                    yaxis = list(title = "Kpar(m-1) = ln(I/I0) * -(1/deltaz)"))


plot_ly(data = par_corrected[c(553:3864),], 
        x = ~Kpar, 
        type = "histogram") %>%
  layout(
    xaxis = list(title = "Kpar(m-1)"),
    yaxis = list(title = "Frequency")
  )

