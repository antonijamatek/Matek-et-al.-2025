#source(path to install and load packages)

#import par data
#insert path to PAR raw data 
par10 <- readr::read_delim("path", delim = ",", show_col_types = FALSE)
par10[4] <- NULL
par40 <- readr::read_delim("path", delim = ",", show_col_types = FALSE)
par40[4] <- NULL

#set tibble
par10 <- as_tibble(par10)
par40 <- as_tibble(par40)

#set TimeStamp POSIXct format by ymd_hms and convert from UTC +2 to UTC +1 using with_tz 
par10$TimeStamp <- with_tz(ymd_hms(par10$TimeStamp), tzone = "Etc/GMT+1")
par40$TimeStamp <- with_tz(ymd_hms(par40$TimeStamp), tzone = "Etc/GMT+1")

#edit data

#PAR10
#omitting values after october
par10 <- par10 %>% filter(par10$TimeStamp < "2022-10-05 23:55:00") 
plot(par10$`PAR [umol/(m^2s)]`)

#PAR40
#removing extreme values from PAR at 40 meters
max(par40$`PAR [umol/(m^2s)]`)
par40 <- par40 %>% filter(par40$`PAR [umol/(m^2s)]` != 1816.8)
par40 <- par40 %>% filter(par40$`PAR [umol/(m^2s)]` != 814.7)
#omitting values after october
par40 <- par40 %>% filter(par40$TimeStamp < "2022-10-05 23:55:00") 
#omitting values between 21st and 23rd (to be comparable w 10m)
par40 <- par40 %>% filter(par40$TimeStamp > "2022-07-23 06:00:00")
#remove the first 23 rows
par40 <- par40[-(1:23),]
plot(par40$`PAR [umol/(m^2s)]`)

length(par10$`PAR [umol/(m^2s)]`)
length(par40$`PAR [umol/(m^2s)]`)


#PLOT, Date is in UTC+1!
plot_ly(data = par10, x = ~ TimeStamp, y = ~ `PAR [umol/(m^2s)]`,  type = 'scatter', mode = 'lines') %>% 
  layout(xaxis = list(title = "Dates"), yaxis = list(title = "PAR [μmol/(m<sup>2</sup>s)]"))

plot_ly(data = par40, x = ~ TimeStamp, y = ~ `PAR [umol/(m^2s)]`,  type = 'scatter', mode = 'lines') %>% 
  layout(xaxis = list(title = "Dates"), yaxis = list(title = "PAR [μmol/(m<sup>2</sup>s)]"))

