#source(path to install and load packages)

#time-indexing 5 min interval data

#PAR10
par10ts <- zoo(par10$`PAR [umol/(m^2s)]`, order.by = par10$TimeStamp)
par10ts

#PAR40
par40ts <- zoo(par40$`PAR [umol/(m^2s)]`, order.by = par40$TimeStamp)
par40ts

#low filtering to 1 hour interval data
window_size <- 12 

#PAR10
x <- tidy(par10ts) #defining x variable so I can extract timestamp vector the same size as one hour time series
timestamp <- x$index
par10ts_12 <- rollapply(par10ts, width = window_size, FUN = mean, align = "center", fill = NA)
par10ts_12 <- aggregate(par10ts_12, as.POSIXct(cut(timestamp, breaks = "hour")), FUN = mean)

#PAR40
x <- tidy(par40ts) #defining x variable so I can extract timestamp vector the same size as one hour time series
timestamp2 <- x$index
par40ts_12 <- rollapply(par40ts, width = window_size, FUN = mean, align = "center", fill = NA)
par40ts_12 <- aggregate(par40ts_12, as.POSIXct(cut(timestamp, breaks = "hour")), FUN = mean)

#check if length of vectors match
length(par10ts_12)
length(par40ts_12)

#ITWs episodes 
#Week 24 July to 6 August 2022 (ITWs: 31 July to 3 August)
#Week 22 to 30 August 2022 (ITWs: 24 - 26 August)

#Filtering 1 hour interval data into weeks of ITWs
par10ts_itw <- par10ts_12[index(par10ts_12) >= as.POSIXct("2022-07-24") 
                          & index(par10ts_12) < as.POSIXct("2022-08-07")
                          |
                          index(par10ts_12) >= as.POSIXct("2022-08-22") 
                          & index(par10ts_12) < as.POSIXct("2022-08-31")]

par40ts_itw <- par40ts_12[index(par40ts_12) >= as.POSIXct("2022-07-24") 
                          & index(par40ts_12) < as.POSIXct("2022-08-07") 
                          |
                          index(par40ts_12) >= as.POSIXct("2022-08-22") 
                          & index(par40ts_12) < as.POSIXct("2022-08-31")]

#Create a data frame
par10_aug <- tidy(par10ts_itw)
par10_aug <- na.omit(par10_aug)
colnames(par10_aug) <- c("TimeStamp", "PAR_10")

par40_aug <- tidy(par40ts_itw)
par40_aug <- na.omit(par40_aug)
colnames(par40_aug) <- c("TimeStamp", "PAR_40")

save(par10_aug, par40_aug, timestamp, file = "par_for_K.RData")