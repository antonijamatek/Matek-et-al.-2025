#source(path to install and load packages)

#import
insitu22 <- readxl::read_xlsx("C:/Users/Tihomir/OneDrive - Prirodoslovno-matematički fakultet/ISLAND/Analiza - Experiment II i III - inverzni model/Statistics/PCA_22_23/insitu_variables22.xlsx")
insitu23 <- readxl::read_xlsx("C:/Users/Tihomir/OneDrive - Prirodoslovno-matematički fakultet/ISLAND/Analiza - Experiment II i III - inverzni model/Statistics/PCA_22_23/insitu_variables23.xlsx")

#**function to define timestamp format <dttm>**: convert to 24-hour (remove AM/PM) and define format as %Y-%m-%d %H:%M:%S
timestamp_format <- function(x) {
  #timestamp structure we are converting (must be the same as in our data frame)
  timestamp <-dmy(x)
  #convert timestamp to the desired format
  formatted_timestamp <- format(timestamp, "%Y-%m-%d %H:%M:%S")
  return(formatted_timestamp)
}

#set format using function timestamp_format():
insitu22$Date <- sapply(insitu22$Date, timestamp_format)
#define as date and time vector <dttm>  using POSIXct(): 
insitu22$Date <- as.POSIXct(insitu22$Date)

#merge data frames
insitu <- bind_rows(insitu22, insitu23)
