#source(path to install and load packages)

insitu_pca23 <- insitu[c(21:37),]
insitu_pca23 <- insitu_pca23[c(4,5,8,12:15)]%>%
  mutate(across(everything(), ~ replace(., is.na(.), 0)))
env_pca23 <- insitu_pca23
factors_pca23 <- factors_pca[c(21:37),]

#log transformed and standardize env data
insitu_pca23_tr <- decostand(insitu_pca23, method = "log", scale = TRUE)
env_pca23_tr <- decostand(env_pca23, method = "log", scale = TRUE)

#preform PCA on biotic data
pca23 <- rda(insitu_pca23_tr, scale = TRUE)
summary(pca23)
set.seed(1)
anova(pca23)

vectors23 <- envfit(pca23 ~ ., data = env_pca23_tr,
                  choices = 1:2,
                  scaling = "symmetric",
                  permutations = 999)

#Plot basic
plot(pca23, display = "sites", type = "n",
     scaling = "symmetric")
points(pca23, display = "species",
       scaling = "symmetric", pch = 6)
points(pca23, display = "sites",
       scaling = "symmetric", pch = 3)
plot(vectors23, add = TRUE)

#######################PLOTTING GGVEGAN########################

#Fortifying the ordination that will be plotted with ggvegan package
#The convention with ggplot2 is to `fortify()` the object we wish to plot, 
#which basically means turn the object into a format that is suitable for plotting with `ggplot()`

ford <- fortify(pca23, axes = 1:2, scaling = "symmetric")
ford <- as_tibble(ford)
ford
species <- fortify(pca23, axes = 1:2, scaling = "symmetric", display = "species")
sites23 <- fortify(pca23, axes = 1:2, scaling = "symmetric", display = "wa")
sites23 <- sites23 %>%
  bind_cols(factors_pca23) #add factors
#bp <- fortify (pca, axes = 1:2, scaling = "symmetric", display = "bp")

#graphic info
vignette("ggplot2-specs")#graphics info
?pch #graphics info
cols <- c("blue", "black", "red") #defining colors for ggplot points


#plot with factor itws and layer
p3 <- ggplot(ford, aes(x = PC1, y = PC2)) +
  geom_hline(yintercept = 0, colour = "black", alpha = 1) +
  geom_vline(xintercept = 0, colour = "black", alpha = 1) + 
  geom_point(data = sites23, 
             mapping = aes(colour = Layer), size = 2.8) +
  scale_color_manual(values = cols) +
  geom_point(data = sites23, 
             mapping = aes(shape = ITWs), size = 4, stroke = 1.1) +
  scale_shape_manual(values = c(0,1)) +
  geom_label(data = species, aes(label = label), label.size = 0.4, cex = 4) +
  geom_segment(data = filter(ford, score == "species"),
               mapping = aes(x = 0, y = 0, xend = PC1 * 0.7, yend = PC2 * 0.7),
               arrow = arrow(length = unit(0.4, "cm"))) + 
  #ggtitle("PCA 2023") + 
  theme_bw() +
  theme(
    panel.grid.major = element_blank(),  # removes major grid lines
    panel.grid.minor = element_blank()   # removes minor grid lines
  ) +
  theme(axis.text.y = element_text(size = rel(2), angle = 0),
        axis.text.x = element_text(size = rel(2), angle = 0),
        axis.title.y = element_text(size = rel(1.5), angle = 90),
        axis.title.x = element_text(size = rel(1.5), angle = 0))+
  labs(x = "PC1 (41.78 %)", y = "PC2 (21.13 %)")


p3

############REPEAT WITHOUT TEMPERATURE#######################

#log transformed and standardize env data
insitu_pca23_tr <- decostand(insitu_pca23[c(-3)], method = "log", scale = TRUE)
env_pca23_tr <- decostand(env_pca23[c(-3)], method = "log", scale = TRUE)

#preform PCA
pca23 <- rda(insitu_pca23_tr, scale = TRUE)
summary(pca23)
set.seed(1)
anova(pca23)

vectors23 <- envfit(pca23 ~ ., data = env_pca23_tr,
                    choices = 1:2,
                    scaling = "symmetric",
                    permutations = 999)

#######################PLOTTING GGVEGAN########################
#fortify
ford <- fortify(pca23, axes = 1:2, scaling = "symmetric")
ford <- as_tibble(ford)
ford
species <- fortify(pca23, axes = 1:2, scaling = "symmetric", display = "species")
sites23 <- fortify(pca23, axes = 1:2, scaling = "symmetric", display = "wa")
sites23 <- sites23 %>%
  bind_cols(factors_pca23) #add factors

#plot with factor itws and layer
p4 <- ggplot(ford, aes(x = PC1, y = PC2)) +
  geom_hline(yintercept = 0, colour = "black", alpha = 1) +
  geom_vline(xintercept = 0, colour = "black", alpha = 1) + 
  geom_point(data = sites23, 
             mapping = aes(colour = Layer), size = 2.8) +
  scale_color_manual(values = cols) +
  geom_point(data = sites23, 
             mapping = aes(shape = ITWs), size = 4, stroke = 1.1) +
  scale_shape_manual(values = c(0,1)) +
  geom_label(data = species, aes(label = label), label.size = 0.4, cex = 4) +
  geom_segment(data = filter(ford, score == "species"),
               mapping = aes(x = 0, y = 0, xend = PC1 * 0.7, yend = PC2 * 0.7),
               arrow = arrow(length = unit(0.4, "cm"))) + 
  #ggtitle("PCA 2023") + 
  theme_bw()+
  theme(
    panel.grid.major = element_blank(),  # removes major grid lines
    panel.grid.minor = element_blank()   # removes minor grid lines
  ) +
  theme(axis.text.y = element_text(size = rel(2), angle = 0),
        axis.text.x = element_text(size = rel(2), angle = 0),
        axis.title.y = element_text(size = rel(1.5), angle = 90),
        axis.title.x = element_text(size = rel(1.5), angle = 0))+
  labs(x = "PC1 (36.32 %)", y = "PC2 (24.59 %)")

p4

#save image
ggsave("PCA23.pdf", plot = p3, width = 12, height = 5)
ggsave("PCA23_2.pdf", plot = p4, width = 12, height = 5)
