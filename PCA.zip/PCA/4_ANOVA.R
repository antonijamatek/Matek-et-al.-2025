#source(path to install and load packages)

#**Set data frames for 2022 and 2023 combined**
anova_22_23 <- cbind(insitu_pca, factors_pca)
anova_22_23 <- as_tibble(anova_22_23)
anova_22_23$Layer <- as_factor(anova_22_23$Layer)
anova_22_23$ITWs <- as_factor(anova_22_23$ITWs)
anova_22_23$Station <- as_factor(anova_22_23$Station)
anova_22_23


#**ANOVA for each dependent variable**

#Station factor
dependent_vars <- c("`PT (z) (mgC/m3d)`", "`Chl a (mg/m3)`", "Temp", "`Sigma-t`", "`Oxygen_mgL-1`")
anova_results <- list()

# Loop through each dependent variable to perform ANOVA
for (var in dependent_vars) {
  # Create formula using backticks for variable names with spaces
  formula <- as.formula(paste0(var, " ~ Station"))
  # Perform ANOVA and store results
  anova_results[[var]] <- summary(aov(formula, data = anova_22_23))
}

print(anova_results)

#Layer factor
dependent_vars <- c("`PT (z) (mgC/m3d)`", "`Chl a (mg/m3)`", "Temp", "`Sigma-t`", "`Oxygen_mgL-1`")
anova_results <- list()

for (var in dependent_vars) {
  # Create formula using backticks for variable names with spaces
  formula <- as.formula(paste0(var, " ~ Layer"))
  # Perform ANOVA and store results
  anova_results[[var]] <- summary(aov(formula, data = anova_22_23))
}

print(anova_results)

#ITWs factor
dependent_vars <- c("`PT (z) (mgC/m3d)`", "`Chl a (mg/m3)`", "Temp", "`Sigma-t`", "`Oxygen_mgL-1`")
anova_results <- list()

for (var in dependent_vars) {
  # Create formula using backticks for variable names with spaces
  formula <- as.formula(paste0(var, " ~ ITWs"))
  # Perform ANOVA and store results
  anova_results[[var]] <- summary(aov(formula, data = anova_22_23))
}

print(anova_results)


##**Post-hoc analysis using Tukey's HSD for each dependent variable**

#Station factor
post_hoc_results <- list()

for (var in dependent_vars) {
  formula <- as.formula(paste(var, "~ Station"))
  post_hoc_results[[var]] <- TukeyHSD(aov(formula, data = anova_22_23))
}

print(post_hoc_results)

#Layer factor
post_hoc_results <- list()

for (var in dependent_vars) {
  formula <- as.formula(paste(var, "~ Layer"))
  post_hoc_results[[var]] <- TukeyHSD(aov(formula, data = anova_22_23))
}

print(post_hoc_results)

#ITWs factor
post_hoc_results <- list()

for (var in dependent_vars) {
  formula <- as.formula(paste(var, "~ ITWs"))
  post_hoc_results[[var]] <- TukeyHSD(aov(formula, data = anova_22_23))
}

print(post_hoc_results)

#############################################################################################

#**Set data frame for 2023 data**
anova23 <- cbind(insitu_pca23, factors_pca23)
anova23 <- as_tibble(anova23)
anova23$Layer <- as_factor(anova23$Layer)
anova23$ITWs <- as_factor(anova23$ITWs)
anova23$Station <- as_factor(anova23$Station)
anova23

#**ANOVA for each dependent variable**
#Station factor
anova_result <- anova(cbind(`PT (z) (mgC/m3d)`, `Chl a (mg/m3)`, Temp, `Sigma-t`, `Oxygen_mgL-1`, `Phosphate [µmol/L]`, `Silicate [µmol/L]`, `Nitrate [µmol/L]`) ~ Station, data = anova23)
summary(anova_result, test = "Pillai")
#Layer factor
anova_result <- anova(cbind(`PT (z) (mgC/m3d)`, `Chl a (mg/m3)`, Temp, `Sigma-t`, `Oxygen_mgL-1`, `Phosphate [µmol/L]`, `Silicate [µmol/L]`, `Nitrate [µmol/L]`) ~ Layer, data = anova23)
summary(anova_result, test = "Pillai")
#ITWs
anova_result <- anova(cbind(`PT (z) (mgC/m3d)`, `Chl a (mg/m3)`, Temp, `Sigma-t`, `Oxygen_mgL-1`, `Phosphate [µmol/L]`, `Silicate [µmol/L]`, `Nitrate [µmol/L]`) ~ ITWs, data = anova23)
summary(anova_result, test = "Pillai")

#Station factor
dependent_vars <- c("`PT (z) (mgC/m3d)`", "`Chl a (mg/m3)`", "Temp", "`Sigma-t`", "`Oxygen_mgL-1`", "`Phosphate [µmol/L]`", "`Silicate [µmol/L]`", "`Nitrate [µmol/L]`")
anova_results <- list()

for (var in dependent_vars) {
  # Create formula using backticks for variable names with spaces
  formula <- as.formula(paste0(var, " ~ Station"))
  # Perform ANOVA and store results
  anova_results[[var]] <- summary(aov(formula, data = anova23))
}

print(anova_results)

#Layer factor
anova_results <- list()

for (var in dependent_vars) {
  # Create formula using backticks for variable names with spaces
  formula <- as.formula(paste0(var, " ~ Layer"))
  # Perform ANOVA and store results
  anova_results[[var]] <- summary(aov(formula, data = anova23))
}

print(anova_results)

#ITWs factor
anova_results <- list()

for (var in dependent_vars) {
  # Create formula using backticks for variable names with spaces
  formula <- as.formula(paste0(var, " ~ ITWs"))
  # Perform ANOVA and store results
  anova_results[[var]] <- summary(aov(formula, data = anova23))
}

print(anova_results)


##**Post-hoc analysis using Tukey's HSD for each dependent variable**

#Station factor
post_hoc_results <- list()

for (var in dependent_vars) {
  formula <- as.formula(paste(var, "~ Station"))
  post_hoc_results[[var]] <- TukeyHSD(aov(formula, data = anova23))
}

print(post_hoc_results)

#Layer factor
post_hoc_results <- list()

for (var in dependent_vars) {
  formula <- as.formula(paste(var, "~ Layer"))
  post_hoc_results[[var]] <- TukeyHSD(aov(formula, data = anova23))
}

print(post_hoc_results)

#ITWs factor
post_hoc_results <- list()

for (var in dependent_vars) {
  formula <- as.formula(paste(var, "~ ITWs"))
  post_hoc_results[[var]] <- TukeyHSD(aov(formula, data = anova23))
}

print(post_hoc_results)
