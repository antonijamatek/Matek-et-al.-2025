#source(path to install and load packages)

insitu_pca <- insitu[c(4,5,8,11:15)]%>%
  mutate(across(everything(), ~ replace(., is.na(.), 0)))
insitu_pca <- insitu_pca[-c(4,6:8)]

env_pca <- insitu_pca

factors_pca <- insitu[c(1:3,16,17)]

#log transformed and standardize env data
insitu_pca2 <- decostand(insitu_pca, method = "log", scale = TRUE)
env_pca2 <- decostand(env_pca, method = "log", scale = TRUE)

#preform PCA on biotic data
pca <- rda(insitu_pca2, scale = TRUE)
summary(pca)

vectors <- envfit(pca ~ ., data = env_pca2,
                  choices = 1:2,
                  scaling = "symmetric",
                 permutations = 999)

#preform test of statistical signficance by applying ANOVA for each axis 
set.seed(1)
anova(pca, permutations = 999)

#Plot basic
plot(pca, display = "sites", type = "n",
     scaling = "symmetric")
points(pca, display = "species",
       scaling = "symmetric", pch = 6)
points(pca, display = "sites",
       scaling = "symmetric", pch = 3)
plot(vectors, add = TRUE)

#######################PLOTTING GGVEGAN########################

#Fortifying the ordination that will be plotted with ggvegan package
#The convention with ggplot2 is to `fortify()` the object we wish to plot, 
#which basically means turn the object into a format that is suitable for plotting with `ggplot()`

ford <- fortify(pca, axes = 1:2, scaling = "symmetric")
ford <- as_tibble(ford)
ford
species <- fortify(pca, axes = 1:2, scaling = "symmetric", display = "species")
sites <- fortify(pca, axes = 1:2, scaling = "symmetric", display = "wa")
sites <- sites %>%
  bind_cols(factors_pca) #add factors
#bp <- fortify (pca, axes = 1:2, scaling = "symmetric", display = "bp")

#graphic info
vignette("ggplot2-specs")#graphics info
?pch #graphics info
cols <- c("blue", "black", "red") #defining colors for ggplot points


##############NO NUTRIENTS ######################
#plot with factor station and layer
p1 <- ggplot(ford, aes(x = PC1, y = PC2)) +
  geom_hline(yintercept = 0, colour = "black", alpha = 1) +
  geom_vline(xintercept = 0, colour = "black", alpha = 1) + 
  geom_point(data = sites, 
             mapping = aes(colour = Layer), size = 2.8) +
  scale_color_manual(values = cols) +
  geom_point(data = sites, 
             mapping = aes(shape = Station), size = 4, stroke = 1.1) +
  scale_shape_manual(values = c(0,1,2,3,4,5)) +
  geom_label(data = species, aes(label = label), label.size = 0.4, cex = 4) +
  geom_segment(data = filter(ford, score == "species"),
               mapping = aes(x = 0, y = 0, xend = PC1 * 0.7, yend = PC2 * 0.7),
               arrow = arrow(length = unit(0.4, "cm"))) + 
  #ggtitle("PCA 2022 and 2023") + 
  theme_bw()+
  theme(
    panel.grid.major = element_blank(),  # removes major grid lines
    panel.grid.minor = element_blank()   # removes minor grid lines
  ) +
  theme(axis.text.y = element_text(size = rel(2), angle = 0),
        axis.text.x = element_text(size = rel(2), angle = 0),
        axis.title.y = element_text(size = rel(1.5), angle = 90),
        axis.title.x = element_text(size = rel(1.5), angle = 0))+
  labs(x = "PC1 (45.10 %)", y = "PC2 (27.95 %)")

p1

#plot with factor itws and layer
p2 <- ggplot(ford, aes(x = PC1, y = PC2)) +
  geom_hline(yintercept = 0, colour = "black", alpha = 1) +
  geom_vline(xintercept = 0, colour = "black", alpha = 1) + 
  geom_point(data = sites, 
             mapping = aes(colour = Layer), size = 2.8) +
  scale_color_manual(values = cols) +
  geom_point(data = sites, 
             mapping = aes(shape = ITWs), size = 4, stroke = 1.1) +
  scale_shape_manual(values = c(0,1)) +
  geom_label(data = species, aes(label = label), label.size = 0.4, cex = 4) +
  geom_segment(data = filter(ford, score == "species"),
               mapping = aes(x = 0, y = 0, xend = PC1 * 0.7, yend = PC2 * 0.7),
               arrow = arrow(length = unit(0.4, "cm"))) + 
  #ggtitle("PCA 2022 and 2023") + 
  theme_bw() +
  theme(
    panel.grid.major = element_blank(),  # removes major grid lines
    panel.grid.minor = element_blank()   # removes minor grid lines
  ) +
  theme(axis.text.y = element_text(size = rel(2), angle = 0),
        axis.text.x = element_text(size = rel(2), angle = 0),
        axis.title.y = element_text(size = rel(1.5), angle = 90),
        axis.title.x = element_text(size = rel(1.5), angle = 0))+
  labs(x = "PC1 (45.10 %)", y = "PC2 (27.95 %)")

p2

ggsave("PCA22_23_without_sigma.pdf", plot = p1, width = 12, height = 5)
ggsave("PCA22_23_2_without_sigma.pdf", plot = p2, width = 12, height = 5)  
 