#source(path to install and load packages)

#insert path to PAR raw data
par10 <- readr::read_delim("path", delim = ",", show_col_types = FALSE)
par30 <- readr::read_delim("path", delim = ",", show_col_types = FALSE)

#editing
#PAR10
#removing last three rows
par10 <- par10[-(4439:4442),]
#editing dataframe
par10[4] <- NULL
colnames(par10)[2] <- "PAR [μmol/(m2s)]"
#PAR30
#importing data
#editing data frame
par30[4] <- NULL
colnames(par30)[2] <- "PAR [μmol/(m2s)]"

#set TimeStamp POSIXct format by ymd_hms and convert from UTC +2 to UTC +1 using with_tz 
par10$TimeStamp <- with_tz(ymd_hms(par30$TimeStamp), tzone = "Etc/GMT+1")
par30$TimeStamp <- with_tz(ymd_hms(par30$TimeStamp), tzone = "Etc/GMT+1")

#check data frame
par10 <- as_tibble(par10)
par10
par30 <- as_tibble(par30)
par30

#checking if lenghts of vectors are equal
length(par10$`PAR [μmol/(m2s)]`)
length(par30$`PAR [μmol/(m2s)]`)
