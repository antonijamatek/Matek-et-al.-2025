#source(path to install and load packages)

load("par_for_K.RData") #generate in script: "2_par_23.time indexing and filtering.R"

#1 hour interval data
par10df <- tidy(par10ts_12)
colnames(par10df) <- c("TimeStamp", "PAR_10")

par30df <- tidy(par30ts_12)
colnames(par30df) <- c("TimeStamp", "PAR_30")

#define data frame for K estimate
par <- merge(par10df, par30df, by = "TimeStamp", suffixes = c("_10", "_30"))

#filter out night (between 20:00 and 06:00 UTC +2)
par <- dplyr::filter(par,!(as.POSIXlt(par$TimeStamp)$hour >= 20 | 
                            as.POSIXlt(par$TimeStamp)$hour < 6))
par <- as_tibble(par)
par

#plot
plot_ly(data = par, x = ~ TimeStamp, y = ~ PAR_10, type = "scatter",
        mode = "lines")%>% layout(xaxis = list(title = "Dates"),
                                    yaxis = list(title = "PAR 10 m [umol/m2s]"))

plot_ly(data = par, x = ~ TimeStamp, y = ~ PAR_30, type = "scatter",
        mode = "lines")%>% layout(xaxis = list(title = "Dates"),
                                          yaxis = list(title = "PAR 30 m [umol/m2s]"))



