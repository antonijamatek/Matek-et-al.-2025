#source(path to install and load packages)

#light function for Kpar estimate
#I <- I0 * e ^ (-Kpar * z)
#I/I0 <- e ^ (-Kpar * z) /ln
#ln(I/I0) <- - Kpar * z

#1 hour interval PAR data for K estimate
par

#input parameters
e <- exp(1) #euler's number
deltaz <- 30 - 10 #difference between the sensor depths
n <-unique(par$TimeStamp)
N <- as.numeric(length(n))
Kpar <- numeric(N)
I <- par$PAR_30
I0 <- par$PAR_10

#Kpar estimation
Kpar <- ln(I/I0) * -(1/deltaz)

#min and max Kpar depth, and range
1/max(Kpar)
1/min(Kpar)
range(Kpar)

#edit dataframe 
par$Kpar <- Kpar


#plot using interactive package
plot_ly(data = par, x = ~TimeStamp, y = ~Kpar, type = 'scatter',
        mode = 'markers') %>% layout(xaxis = list(title = "Dates"),
       yaxis = list(title = "Kpar(m-1) = ln(I/I0) * -(1/deltaz)"))

#using function slice () from dplyr package to subset the data directly in plotly
plot_ly(data = slice(par, 12:2582), x = ~TimeStamp, y = ~Kpar, 
        type = 'scatter', mode = 'markers') %>% layout(xaxis = list(title = "Dates"), 
       yaxis = list(title = "Kpar(m-1) = ln(I/I0) * -(1/deltaz)"))


#edit data frame to remove extremes
par_K <- par[-c(1:12, 2581:2638),]
par_K <- dplyr::filter(par.corrected, Kpar <= 0.1 & Kpar > 0)

#remove ''tails'' - leave data between 8:00 and 18:00
par_K <- dplyr::filter(par_K, !(as.POSIXlt(par_K$TimeStamp)$hour >= 18 
                                               | as.POSIXlt(par_K$TimeStamp)$hour < 8))

#plot final data frame
plot_ly(data = par_K, x = ~TimeStamp, y = ~Kpar, 
        type = 'scatter', mode = 'markers') %>% 
        layout(xaxis = list(title = "Dates"), 
         yaxis = list(title = "Kpar(m-1) = ln(I/I0) * -(1/deltaz)"))
