#source(path to install and load packages)

#set the locale to English for time-related operations
Sys.setlocale("LC_TIME", "C")


#########################################
####  CREATE DATA FRAME FOR IN SITU  ####
#########################################


#import
insitu <- readxl::read_xlsx("insert path to: in_situ_pp_chl_a_23.xlsx")

timestamp_format <- function(x) {
  #timestamp structure we are converting (must be the same as in our data frame)
  timestamp <- dmy(x)
  #convert timestamp to the desired format
  formatted_timestamp <- format(timestamp, "%Y-%m-%d")
  return(formatted_timestamp)
}

#edit
insitu <- as_tibble(insitu)
insitu$Date <- sapply(insitu$Date, timestamp_format)
insitu$Date <- as.POSIXct.default(insitu$Date)
insitu
#filter out s0a-16
insitu <- insitu[c(12:17),] 
insitu
insitu <- insitu[-c(3, 5:7)]
insitu
colnames(insitu)[3] <- "NPP_mg_m-3_day-1"
colnames(insitu)[1] <- "Longitude"
colnames(insitu)[2] <- "Depth"
insitu[1] <- 16.89900
insitu$Latitude <- 42.72889
insitu <- insitu %>%
  dplyr::select(Longitude, Latitude, Depth, `NPP_mg_m-3_day-1`)
insitu


######################################
##  IMPORT AND EXTRACT MODEL DATA ####
######################################


#import model data - analysis and forecast (https://data.marine.copernicus.eu/product/MEDSEA_ANALYSISFORECAST_BGC_006_014/download?dataset=cmems_mod_med_bgc-bio_anfc_4.2km_P1D-m_202211)
DataMod <- open.nc("insert path to cmems_mod_med_bgc-bio_anfc_4.2km_P1D-m_1730198745689.nc")
print.nc(DataMod) 

#extract variables
mod.npp <- var.get.nc(DataMod, 'nppv', unpack=TRUE)
mod.unit <- att.get.nc(DataMod, "nppv", "units")
mod.lat <- var.get.nc(DataMod, 'latitude')
mod.lon <- var.get.nc(DataMod, 'longitude')
as.Date(utcal.nc(att.get.nc(DataMod, "time", "units"), var.get.nc(DataMod, 'time'), "s"))


#########################################
####  CREATE DATA FRAME FOR MODEL ######
#########################################

# Function to find the nearest depth levels
find_nearest <- function(value, candidates) {
  return(candidates[which.min(abs(candidates - value))])
}

# Aligning model depths with in situ depths
z <- insitu$Depth
Z <- var.get.nc(DataMod, 'depth')

# Apply this function to all in situ depths
nearest_depth_levels <- sapply(z, find_nearest, candidates = Z)

# Create a mask for the nearest depth levels
depth_mask <- Z %in% nearest_depth_levels
depth_mask

# Extract the relevant NPP data based on the filtered depths
mod.npp <- var.get.nc(DataMod, 'nppv')[,,depth_mask, drop=FALSE]

#Filter depths 
depth_levels_filtered <- Z[depth_mask]

#Flat the array into dataframe
model <- melt(mod.npp, varnames = c("LonIdx","LatIdx","DepthIdx"), value.name = "NPP")
model <- model %>%
  mutate(Longitude = mod.lon[LonIdx],
         Latitude = mod.lat[LatIdx],
         Depth = Z[DepthIdx]) %>%
  dplyr::select(Longitude,Latitude,Depth, NPP)
colnames(model)[4] <- "NPP_mg_m-3_day-1"
model

#Remove rows with missing NPP values
model <- model[!is.na(model$`NPP_mg_m-3_day-1`), ]
row.names(model) <- NULL
model

#########################################
####  ESTIMATE WATER COLUMN PRODUCTION ###
#########################################


# Function to perform trapezoidal integration
trapezoidal_integration <- function(depths, npp) {
  # Ensure the data is sorted by depth
  order_index <- order(depths)
  depths <- depths[order_index]
  npp <- npp[order_index]
  
  # Apply trapezoidal integration formula
  npp_integral <- sum(((npp[-length(npp)] + npp[-1]) / 2) * (depths[-1] - depths[-length(depths)]))
  return(npp_integral)
}

#In situ 
insitu_df <- insitu %>%
  group_by(Longitude, Latitude) %>%
  summarise(
    NPP = trapezoidal_integration(Depth, `NPP_mg_m-3_day-1`)
  )
colnames(insitu_df)[3] <- "NPP_mg_m-2_d-1"
insitu_df  

#Model
model_df <- model %>%
  arrange(Longitude, Latitude, Depth) %>%
  group_by(Longitude, Latitude) %>%
  summarise(
    NPP = trapezoidal_integration(Depth, `NPP_mg_m-3_day-1`)
  )
colnames(model_df)[3] <- "NPP_mg_m-2_d-1"
model_df


#########################################
####  CREATE DATA FRAME FOR ANALYSIS ######
#########################################

# Function to calculate the Euclidean distance between two points given their longitude and latitude
calculate_distance <- function(lon1, lat1, lon2, lat2) {
  sqrt((lon1 - lon2)^2 + (lat1 - lat2)^2)
}

#finding matching grids
#in_situ_location <- insitu_df %>% 
# dplyr::select(Longitude, Latitude) %>% 
#  distinct()

# Find the closest grid point in model and reanalysis data
model_df <- model_df %>% 
  mutate(Distance = calculate_distance(Longitude, Latitude, 
                                       insitu_df$Longitude, insitu_df$Latitude)) %>% 
  arrange(Distance)

# Combine in situ and model data 
combined_df <- bind_rows(
  model_df %>% mutate(Type = "Model"),
  insitu_df %>% mutate(Type = "In Situ")  # Add in situ data
)
