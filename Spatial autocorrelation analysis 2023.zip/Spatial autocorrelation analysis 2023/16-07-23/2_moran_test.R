#source(path to install and load packages)

#set the locale to English for time-related operations
Sys.setlocale("LC_TIME", "C")


##################################
###### SPATIAL WEIGHT MATRIX #####
##################################


#A spatial weight matrix defines the spatial relationships between the data points (e.g., how close they are to each other)
#Weights in spatial analysis define how strongly or closely points are related based on their spatial locations. 
#They are crucial for understanding spatial patterns and dependencies.

# Create spatial coordinates for combined data
coordinates <- as.matrix(combined_df %>% dplyr::select(Longitude, Latitude))

# Calculate Distance Matrix
dist_matrix <- as.matrix(dist(coordinates))

# Replace zero distances with NA (or a very small number) to avoid division by zero
dist_matrix[dist_matrix == 0] <- NA

# Create Inverse Distance Matrix
dist_inv <- 1 / dist_matrix

# Replace NA and inf values
dist_inv[is.na(dist_inv)] <- 0
dist_inv[is.infinite(dist_inv)] <- 0

# Create spatial weights list
spatial_weights <- mat2listw(dist_inv, style = "W")


##############################################################
###### SPATIAL AUTOCORELLATION ANALYSIS - LOCAL MORAN'S I #####
##################################################################


# Calculate Local Moran's I
local_moran <- localmoran(combined_df$`NPP_mg_m-2_d-1`, spatial_weights)

# Calculate Getis-Ord Gi*
gi_star <- localG(combined_df$`NPP_mg_m-2_d-1`, spatial_weights)

# Extract quadrant information
quadrant_info <- attr(local_moran, "quadr")

# Add results to dataframe
combined_df$Local_Moran_I <- local_moran[, "Ii"]
combined_df$Z_score <- local_moran[, "Z.Ii"]
combined_df$p_value <- local_moran[, "Pr(z != E(Ii))"]
combined_df$GetisOrd_GiStar <- gi_star
combined_df$quadrant_mean <- quadrant_info$mean
combined_df$quadrant_pysal <- quadrant_info$pysal

# Store data in .xlsx file
writexl::write_xlsx(filtered_data, path= " ")