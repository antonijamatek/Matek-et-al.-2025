#source(path to install and load packages)

#set the locale to English for time-related operations
Sys.setlocale("LC_TIME", "C")

# Filter to visualize only significant data 
filtered_data <- combined_df %>%
  filter((Z_score > 1.96 | Z_score < -1.96) & p_value <= 0.05)

# Define bounding box for Lastovo Island
lastovo <- st_read("path to lastovo_island.shp")
st_crs(lastovo) <- 4326

#Plot Lastovo
ggplot() +
  geom_sf(data = lastovo, fill = "lightgrey", color = "black")


filtered_data[21,1] <- 16.86121
filtered_data[21,2] <- 42.72624


# Convert data frame to an sf object
grid_sf <- st_as_sf(filtered_data, coords = c("Longitude", "Latitude"), crs = 4326)

#######################################
####### PLOT LOCAL MORAN'S I ##########
#######################################

ggplot() +
  
  geom_sf(data = lastovo, fill = "lightgrey", color = "black")+
  
  # Plot the grid with Local Moran's I values
  geom_sf(data = grid_sf, aes(color = Local_Moran_I), size = 3) +
  
  # Add color scale for Local Moran's I values
  scale_color_viridis_c(name = "Local Moran's I", option = "plasma") +
  
  # Add labels and title
  labs(
    title = "Grid Points Colored by Local Moran's I",
    x = "Longitude",
    y = "Latitude"
  ) +
  
  # Set minimal theme for a cleaner look
  theme_minimal()

##################################################################
####### PLOT LOCAL MORAN'S I AND QUADRANT CLASSIFICATION##########
##################################################################

ggplot() +
  # Plot the base map with the island
  geom_sf(data = lastovo, fill = "lightgrey", color = "black") +
  
  # Plot the grid points with Local Moran's I values using color
  geom_sf(data = grid_sf, aes(color = Local_Moran_I), size = 3) +
  
  # Overlay the quadrant classifications using shapes
  geom_sf(data = grid_sf, aes(shape = quadrant_pysal), size = 4.5, fill = NA, stroke = 1.1) +
  
  # Add color scale for Local Moran's I values
  scale_color_viridis_c(name = "Local Moran's I", option = "plasma", limits = c(-2, 2)) +
  
  # Add a shape scale for quadrant classification
  scale_shape_manual(name = "Quadrant Classification",
                     values = c("High-Low" = 23, "Low-High" = 22, "High-High" = 24, "Low-Low" = 25)) +
  
  # Add labels and title
  labs(
    #title = "Grid Points with Local Moran's I and Quadrant Classification",
    subtitle = "2023-07-16",
    x = "Longitude",
    y = "Latitude"
  )+
  theme_bw() +
    theme(
      panel.grid.major = element_blank(),  # removes major grid lines
      panel.grid.minor = element_blank()   # removes minor grid lines
    ) 

######################################################################################
####### PLOT SATELLITE CHL A WITH LOCAL MORAN'S I AND QUADRANT CLASSIFICATION ########
######################################################################################


# Import NetCDF of satellite data
FileSat <- "insert path to cmems_obs-oc_med_bgc-plankton_my_l4-gapfree-multi-1km_P1D_1730885869790.nc"
DataSat <- open.nc(FileSat)
print.nc(DataSat) 

# Extract Satellite data
Sat.chl <- var.get.nc(DataSat, 'CHL', unpack=TRUE)
summary(Sat.chl)

Sat.lat <- var.get.nc(DataSat, 'latitude')
Sat.lon <- var.get.nc(DataSat, 'longitude')

Sat.time <- var.get.nc(DataSat, 'time')
Sat.TimeUnit <- att.get.nc(DataSat, "time", "units")

Sat.date <- as.Date(utcal.nc(Sat.TimeUnit, Sat.time, "s"))
print(Sat.date)


# Formating Data for Plotting
FormatDF <- function(Data, Lat, Lon) {
  # This function formats Data as dataframe
  
  # Creates a grid of lat and long
  Grid.lat <- rep(Lat, each = length(Lon))
  Grid.lon <- rep(Lon, times = length(Lat))
  
  # Flatten data
  Values <- as.vector(Data)
  
  # Creates a dataframe
  DF <- data.frame(x = Grid.lon, y = Grid.lat, Vals = Values)
  
  return(DF)
}

# Apply function to dataseT
Sat.DF <- FormatDF(Sat.chl, Sat.lat, Sat.lon)
head(Sat.DF)


# Function for plotting satellite data
PlotMap <- function(DF, title=NULL, subtitle=NULL, caption=NULL) {
  # Import country layer from Natural Earth
  Countries <- ne_countries(scale = "medium", returnclass = "sf")
  
  # Calculate longitude and latitude limits from the dataframe
  LonMin <- min(DF$x, na.rm = TRUE)
  LonMax <- max(DF$x, na.rm = TRUE)
  LatMin <- min(DF$y, na.rm = TRUE)
  LatMax <- max(DF$y, na.rm = TRUE)
  
  # Generate the plot
  plot <- ggplot() +
    # Plot data
    geom_tile(data=DF, aes(x=x, y=y, fill=Vals)) +
    
    # Color scale options
    scale_fill_distiller(palette="Spectral", name="Satellite chl a [mg/m3]", limits = c(0.039, 0.09)) +
    
    # Add country layer
    #geom_sf(data=Countries, fill=grey(0.9), color=grey(0.6), lwd = 0.2) +
    
    #Define latitude and longitude limits
    coord_sf(xlim=c(LonMin, LonMax),
             ylim=c(LatMin, LatMax), expand=FALSE) +
    
    # General aesthetic options
    theme_light() +
    
    # Title and subtitle
    labs(title = title,
         subtitle = subtitle,
         x = "Longitude",
         y = "Latitude",
         caption = caption) 
  
  # Legend position and aesthetic options
  theme(legend.background = element_rect(fill=grey(0.95),
                                         linewidth=0.5, linetype="solid", 
                                         colour ="darkblue"))
  
  # Return the plot object
  return(plot)
}

# Apply function to plot satellite chl a
Sat.plot <- PlotMap(Sat.DF) 
Sat.plot


#########################RESAMPLING CHL A SATELLITE DATA####################################

# Create a raster object
r <- raster(ncol = length(unique(Sat.DF$x)), nrow = length(unique(Sat.DF$y)),
            xmn = min(Sat.DF$x), xmx = max(Sat.DF$x),
            ymn = min(Sat.DF$y), ymx = max(Sat.DF$y))

# Rasterize the data: Use x and y columns for coordinates and 'Vals' for the values
rasterized <- rasterize(Sat.DF[, c("x", "y")], r, field = Sat.DF$Vals, fun = mean)

# Set the CRS (Coordinate Reference System)
crs(rasterized) <- CRS("+proj=longlat +datum=WGS84") 
plot(rasterized)

# Double the resolution
r_resampled <- disaggregate(rasterized, fact = 4, method = 'bilinear')
plot(r_resampled)

# Shift the raster down by adjusting ymin and ymax
extent_shifted <- extent(xmin(r_resampled), xmax(r_resampled), ymin(r_resampled) - 0.011, ymax(r_resampled) - 0.011)
# Apply the new extent while keeping the resolution
r_shifted <- setExtent(r_resampled, extent_shifted, keepres = TRUE)
plot(r_shifted)

# Convert shapefile to raster for masking
land_mask <- rasterize(lastovo, r_shifted)

# Mask satellite data to exclude land
r_masked <- mask(r_shifted, land_mask, inverse = TRUE)

# Plot the final raster to check alignment
plot(r_masked, main = "Masked and Shifted Satellite Data")

# Set CRS for the raster (if not already set)
crs(r_masked) <- 4326

# Check if shapefile CRS is correct
#crs(r_masked)
#st_crs(lastovo)
#st_crs(grid_sf)

# Convert raster to data frame
Sat.DF_2 <- as.data.frame(r_masked, xy = TRUE)
colnames(Sat.DF_2) <- c("x", "y", "Vals")
Sat.DF_2 <- na.omit(Sat.DF_2) #remove NA values
head(Sat.DF_2)

#Check min and max value of chl a
min(Sat.DF_2$Vals, na.rm = TRUE)
max(Sat.DF_2$Vals, na.rm = TRUE)

# Plot with ggplot
Sat.plot <- ggplot() +
  # Plot the base map with the island
  #geom_sf(data = lastovo, fill = "lightgrey", color = "black") +
  # Plot data 
  geom_tile(data = Sat.DF_2, aes(x = x, y = y, fill = Vals)) +
  # Color scale options
  scale_fill_distiller(palette = "Spectral", 
                       name = "Satellite chl a [mg/m3]",
                       trans = "log",
                       values = scales::rescale(c(0.03, 0.06, 0.09)),  # Ensures the colors correspond to -2, 0, 2
                       limits = c(0.03, 0.09))+
  # General aesthetic options
  theme_light() +
  # Title and subtitle
  labs(x = "Longitude",
       y = "Latitude") 

Sat.plot

################################
##########FINAL PLOT############
################################

Final.plot <- Sat.plot + 
  # Plot the base map with the island
  geom_sf(data = lastovo, fill = "lightgrey", color = "black") +
  # Plot the grid points with Local Moran's I values using color
  geom_sf(data = grid_sf, aes(color = Local_Moran_I), size = 3) +
  # Overlay the quadrant classifications using shapes
  geom_sf(data = grid_sf, aes(shape = quadrant_pysal), size = 4.5, fill = NA, stroke = 1.3) +
  # Add color scale for Local Moran's I values
  scale_color_gradientn(
    name = "Local Moran's I", 
    colors = c("blue", "white", "red"),  # Blue for negative, white for near zero, red for positive
    values = scales::rescale(c(-1.5, 0, 1.5)),  # Ensures the colors correspond to -2, 0, 2
    limits = c(-1.5, 1.5)  # Sets the range of the color scale
  ) +
  # Add a shape scale for quadrant classification
  scale_shape_manual(name = "Quadrant Classification",
                     values = c("High-Low" = 23, "Low-High" = 22, "High-High" = 24, "Low-Low" = 25)) +
  # Add labels and title
  labs(
    # title = "Grid Points with Local Moran's I and Quadrant Classification",
    subtitle = "2023-07-16",
    x = "Longitude",
    y = "Latitude"
  )+
  theme_bw() +
  theme(
    panel.grid.major = element_blank(),  # removes major grid lines
    panel.grid.minor = element_blank()   # removes minor grid lines
  ) 

Final.plot

#save
ggsave("moran_s0a-16.pdf", plot = Final.plot, width = 10, height = 5)


#save Sat.DF to preform ANOVA and post-hoc o chl a satellite data
writexl::write_xlsx(Sat.DF, "sat.chl_s0a-16.xlsx") #will be used to create sat.chl_all.xlsx, data frame for anova
