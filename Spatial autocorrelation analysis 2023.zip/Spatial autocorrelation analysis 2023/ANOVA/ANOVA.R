#source(path to install and load packages)

#input data
df <- readxl::read_xlsx("path to moran.xlsx")

timestamp_format <- function(x) {
  #timestamp structure we are converting (must be the same as in our data frame)
  timestamp <- ymd (x)
  #convert timestamp to the desired format
  formatted_timestamp <- format(timestamp, "%Y-%m-%d")
  return(formatted_timestamp)
}

#edit
df <- as_tibble(df)
df$Date <- sapply(df$Date, timestamp_format)
df$Date <- as.POSIXct.default(df$Date)
moran
# Convert Date to a factor for MANOVA analysis
df <- df %>% mutate(Date = as.factor(Date))
colnames(df)[4] <- "watercolumn_production"
df

#**Conduct ANOVA for each dependent variable**

anova_results_model <- list()
dependent_vars <- c("Local_Moran_I", "watercolumn_production")
for (var in dependent_vars) {
  formula <- as.formula(paste(var, "~ Date"))
  anova_results_model[[var]] <- summary(aov(formula, data = df))
}
anova_results_model


#**Post-hoc analysis using Tukey's HSD for each dependent variable**
post_hoc_results_model <- list()
for (var in dependent_vars) {
  formula <- as.formula(paste(var, "~ Date"))
  post_hoc_results_model[[var]] <- TukeyHSD(aov(formula, data = df))
}
print(post_hoc_results_model)


#####################################
####SATELLITE CHLOROPHYLL DATA##########
#####################################
sat.chl <- readxl::read_xlsx("path to sat.chl_all.xlsx")

#edit
sat.chl <- as_tibble(sat.chl)

# Convert Station and ITW to a factor
sat.chl <- sat.chl %>% mutate(Station = as.factor(Station))
sat.chl <- sat.chl %>% mutate(ITW = as.factor(ITW))
colnames(sat.chl)[4] <- "Chl_a"
sat.chl


#**ANOVA for each dependent variable**

#Station
anova_results <- list()
dependent_vars <- c("Chl_a")
for (var in dependent_vars) {
  formula <- as.formula(paste(var, "~ Station"))
  anova_results[[var]] <- summary(aov(formula, data = sat.chl))
}
anova_results

#ITWs
anova_results <- list()
for (var in dependent_vars) {
  formula <- as.formula(paste(var, "~ ITW"))
  anova_results[[var]] <- summary(aov(formula, data = sat.chl))
}
anova_results

#**Post-hoc analysis using Tukey's HSD for each dependent variable**

#Station
post_hoc_results <- list()
for (var in dependent_vars) {
  formula <- as.formula(paste(var, "~ Station"))
  post_hoc_results[[var]] <- TukeyHSD(aov(formula, data = sat.chl))
}
print(post_hoc_results)

#ITWs
post_hoc_results <- list()
for (var in dependent_vars) {
  formula <- as.formula(paste(var, "~ ITW"))
  post_hoc_results[[var]] <- TukeyHSD(aov(formula, data = sat.chl))
}
print(post_hoc_results)
